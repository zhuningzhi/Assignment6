package Assignment6;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class registergui extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	String str;
	String str1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */


	/**
	 * Create the dialog.
	 */
	public registergui() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewAccount = new JLabel("new account");
			lblNewAccount.setBounds(54, 78, 78, 24);
			contentPanel.add(lblNewAccount);
		}
		{
			textField = new JTextField();
			textField.setBounds(154, 80, 66, 21);
			contentPanel.add(textField);
			textField.setColumns(10);
		}
		{
			JLabel lblNewPassword = new JLabel("new password");
			lblNewPassword.setBounds(54, 147, 100, 15);
			contentPanel.add(lblNewPassword);
		}
		{
			textField_1 = new JTextField();
			textField_1.setBounds(154, 144, 66, 21);
			contentPanel.add(textField_1);
			textField_1.setColumns(10);
		}
		{
			textField_2 = new JTextField();
			textField_2.setBounds(271, 111, 66, 21);
			contentPanel.add(textField_2);
			textField_2.setColumns(10);
		}
		{
			JButton btnOk = new JButton("OK");
			btnOk.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					str=textField.getText();
					str1=textField_1.getText();
					String uri="jdbc:mysql";
					String id="localhost:3306";
					String datasorce="pet_schema";
					String password="mysql175";
					ModifyTable modify=new ModifyTable();
					modify.setUri(uri);
					modify.setId(id);
					modify.setDatasourceName(datasorce);
					modify.setPassword(password);
					
					modify.setSQL("INSERT INTO account VALUES('"+str+"','"+str1+"')");
					String backmess =modify.modifyRecord();
					textField_2.setText(backmess);
				}
			});
			btnOk.setBounds(201, 192, 93, 41);
			contentPanel.add(btnOk);
		}

	}

}
