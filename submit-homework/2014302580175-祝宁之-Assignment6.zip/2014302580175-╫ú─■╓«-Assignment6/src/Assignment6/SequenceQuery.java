package Assignment6;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//��Ϊ����java������������Ƶڶ��桷��p351ҳʵ��java����
import java.util.ArrayList;

public class SequenceQuery extends Query{
	/*String str1;
	String str2;
	String str3;
	int id;
	String account;
	public void setAccount (String account){
		this.account=account;
	}
	public  void getQuery(){
		setSQL("select * from "+tableName+" where account = '"+account+"'");

		Connection con;
		Statement sql;
		ResultSet rs;
		try{
			String url=uri+"://"+id+"/"+datasourceName+"?"+ "user=root&password="+password;
			con =DriverManager.getConnection(url);
			DatabaseMetaData metadata =con.getMetaData();
			ResultSet rs1=metadata.getColumns(null, null, tableName, null);
			int num=0;
			while(rs1.next()){
				num++;
			}
			sql=con.createStatement();
			rs=sql.executeQuery(SQL);
			while(rs.next()){
				
				for(int k=1;k<=num;k++){
					if(k==3){str3=rs.getString(k);id=Integer.parseInt(str3);}
					if(k==1){str1=rs.getString(k);}
					if(k==2){str2=rs.getString(k);}

				}
			
			}
			con.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
	}*/
	public ArrayList<StringBuffer>getQueryResult(){
		setSQL("select * from "+tableName);
		return super.getQueryResult();
	}
}
