package Assignment6;

public class accountlist {
String account;
String password;
int id;
}
