package Assignment6;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class miangui extends JDialog {

	accountlist act=new accountlist();
	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {

			miangui dialog = new miangui();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public miangui() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JButton btnEnter = new JButton("Enter");
			btnEnter.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					SequenceQuery query=new SequenceQuery();
					String uri="jdbc:mysql";
					String id="localhost:3306";
					String datasorce="pet_schema";
					String password="mysql175";
					String tableName="account";
					String str=textField.getText();
					String str1=textField_1.getText();
					String str2=" "+str+"  "+str1+" ";
					String str3;
				
					boolean b=false;
					query.setUri(uri);
					query.setId(id);
					query.setDatasourceName(datasorce);
					query.setPassword(password);
					query.setTableName(tableName);
	/*
					query.setAccount(str);
					query.getQuery();
					str3=query.str1+query.str2;*/
					
					
					ArrayList<StringBuffer>result=query.getQueryResult();
					for(StringBuffer str4:result){
						str3=str4.toString();
						if(str2.equals(str3))
						{
							b=true; textField_2.setText("have done");
							act.account=textField.getText();
							act.password=textField_1.getText();
							

						try {
							showgui dialog = new showgui();
							dialog.act=act;
							dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
							dialog.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
						}
						
					
					if(b==false)textField_2.setText("you are wrong");
					
						

						/*
						 if(str2.equals(str3))
						{
							b=true; textField_2.setText("have done");
							act.account=textField.getText();
							act.password=textField_1.getText();
							

						try {
							showgui dialog = new showgui();
							dialog.act=act;
							dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
							dialog.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
						}
						
					
					if(b==false)textField_2.setText("you are wrong");*/
					
				}
				}
				});
			btnEnter.setBounds(117, 156, 93, 23);
			contentPanel.add(btnEnter);
		}
		{
			JButton btnRegister = new JButton("Register");
			btnRegister.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					try {
						registergui dialog2 = new registergui();
						dialog2.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
						dialog2.setVisible(true);
						
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			});
			btnRegister.setBounds(252, 156, 93, 23);
			contentPanel.add(btnRegister);
		}
		
		JLabel lblAccount = new JLabel("Account");
		lblAccount.setBounds(64, 60, 54, 15);
		contentPanel.add(lblAccount);
		
		JLabel lblPassword = new JLabel("password");
		lblPassword.setBounds(64, 112, 54, 15);
		contentPanel.add(lblPassword);
		
		textField = new JTextField();
		textField.setBounds(178, 57, 66, 21);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(178, 109, 66, 21);
		contentPanel.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(279, 82, 66, 21);
		contentPanel.add(textField_2);
		textField_2.setColumns(10);
	}
}
