package Assignment6;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class showgui extends JDialog {
	accountlist act=new accountlist();
	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	QueryByNumber querybynumber =new QueryByNumber();
	
	String uri="jdbc:mysql";
	String id="localhost:3306";
	String datasorce="pet_schema";
	String password="mysql175";
	private JTextField textField_5;
	private JTextField textField_6;



	/**
	 * Launch the application.
	 */

	/**
	 * Create the dialog.
	 */
	public showgui() {
		setBounds(100, 100, 450, 427);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		String tableName="pet";
		querybynumber.setUri(uri);
		querybynumber.setId(id);
		querybynumber.setDatasourceName(datasorce);
		querybynumber.setPassword(password);
		querybynumber.setTableName(tableName);

	
		
		JButton btnNewButton = new JButton("1-pet");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				act.id=1;
				querybynumber.setNumber(1);
				querybynumber.getQuery();
				textField.setText(querybynumber.str1);
				textField_1.setText(querybynumber.str2);
				textField_2.setText(querybynumber.str3);
				textField_3.setText(querybynumber.str4);
				textField_4.setText(querybynumber.str5);
			
			}
		});
		btnNewButton.setBounds(10, 247, 93, 23);
		contentPanel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("5-pet");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				act.id=5;
				querybynumber.setNumber(5);
				querybynumber.getQuery();
				textField.setText(querybynumber.str1);
				textField_1.setText(querybynumber.str2);
				textField_2.setText(querybynumber.str3);
				textField_3.setText(querybynumber.str4);
				textField_4.setText(querybynumber.str5);
			}
		});
		btnNewButton_1.setBounds(10, 290, 93, 23);
		contentPanel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("9-pet");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				act.id=9;
				querybynumber.setNumber(9);
				querybynumber.getQuery();
				textField.setText(querybynumber.str1);
				textField_1.setText(querybynumber.str2);
				textField_2.setText(querybynumber.str3);
				textField_3.setText(querybynumber.str4);
				textField_4.setText(querybynumber.str5);
			}
		});
		btnNewButton_2.setBounds(10, 335, 93, 23);
		contentPanel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("2-pet");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				act.id=2;
				querybynumber.setNumber(2);
				querybynumber.getQuery();
				textField.setText(querybynumber.str1);
				textField_1.setText(querybynumber.str2);
				textField_2.setText(querybynumber.str3);
				textField_3.setText(querybynumber.str4);
				textField_4.setText(querybynumber.str5);
			}
		});
		btnNewButton_3.setBounds(123, 247, 93, 23);
		contentPanel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("3-pet");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				act.id=3;
				querybynumber.setNumber(3);
				querybynumber.getQuery();
				textField.setText(querybynumber.str1);
				textField_1.setText(querybynumber.str2);
				textField_2.setText(querybynumber.str3);
				textField_3.setText(querybynumber.str4);
				textField_4.setText(querybynumber.str5);
			}
		});
		btnNewButton_4.setBounds(226, 247, 93, 23);
		contentPanel.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("4-pet");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				act.id=4;
				querybynumber.setNumber(4);
				querybynumber.getQuery();
				textField.setText(querybynumber.str1);
				textField_1.setText(querybynumber.str2);
				textField_2.setText(querybynumber.str3);
				textField_3.setText(querybynumber.str4);
				textField_4.setText(querybynumber.str5);
			}
		});
		btnNewButton_5.setBounds(329, 247, 93, 23);
		contentPanel.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("6-pet");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				act.id=6;
				querybynumber.setNumber(6);
				querybynumber.getQuery();
				textField.setText(querybynumber.str1);
				textField_1.setText(querybynumber.str2);
				textField_2.setText(querybynumber.str3);
				textField_3.setText(querybynumber.str4);
				textField_4.setText(querybynumber.str5);
			}
		});
		btnNewButton_6.setBounds(123, 290, 93, 23);
		contentPanel.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("10-pet");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				act.id=10;
				querybynumber.setNumber(10);
				querybynumber.getQuery();
				textField.setText(querybynumber.str1);
				textField_1.setText(querybynumber.str2);
				textField_2.setText(querybynumber.str3);
				textField_3.setText(querybynumber.str4);
				textField_4.setText(querybynumber.str5);
			}
		});
		btnNewButton_7.setBounds(123, 335, 93, 23);
		contentPanel.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("7-pet");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				act.id=7;
				querybynumber.setNumber(7);
				querybynumber.getQuery();
				textField.setText(querybynumber.str1);
				textField_1.setText(querybynumber.str2);
				textField_2.setText(querybynumber.str3);
				textField_3.setText(querybynumber.str4);
				textField_4.setText(querybynumber.str5);
			}
		});
		btnNewButton_8.setBounds(226, 290, 93, 23);
		contentPanel.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("11-pet");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				act.id=11;
				querybynumber.setNumber(11);
				querybynumber.getQuery();
				textField.setText(querybynumber.str1);
				textField_1.setText(querybynumber.str2);
				textField_2.setText(querybynumber.str3);
				textField_3.setText(querybynumber.str4);
				textField_4.setText(querybynumber.str5);
			}
		});
		btnNewButton_9.setBounds(226, 335, 93, 23);
		contentPanel.add(btnNewButton_9);
		
		JButton btnNewButton_10 = new JButton("8-pet");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				act.id=8;
				querybynumber.setNumber(8);
				querybynumber.getQuery();
				textField.setText(querybynumber.str1);
				textField_1.setText(querybynumber.str2);
				textField_2.setText(querybynumber.str3);
				textField_3.setText(querybynumber.str4);
				textField_4.setText(querybynumber.str5);
			}
		});
		btnNewButton_10.setBounds(329, 290, 93, 23);
		contentPanel.add(btnNewButton_10);
		
		JButton btnNewButton_11 = new JButton("12-pet");
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				act.id=12;
				querybynumber.setNumber(12);
				querybynumber.getQuery();
					textField.setText(querybynumber.str1);
					textField_1.setText(querybynumber.str2);
					textField_2.setText(querybynumber.str3);
					textField_3.setText(querybynumber.str4);
					textField_4.setText(querybynumber.str5);
			}
		});
		btnNewButton_11.setBounds(329, 335, 93, 23);
		contentPanel.add(btnNewButton_11);
		
		JLabel lblNewLabel = new JLabel("name");
		lblNewLabel.setBounds(28, 31, 54, 15);
		contentPanel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("eat");
		lblNewLabel_1.setBounds(28, 69, 54, 15);
		contentPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("drink");
		lblNewLabel_2.setBounds(28, 109, 54, 15);
		contentPanel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("live");
		lblNewLabel_3.setBounds(28, 151, 54, 15);
		contentPanel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("hobby");
		lblNewLabel_4.setBounds(28, 192, 54, 15);
		contentPanel.add(lblNewLabel_4);
		
		textField = new JTextField();
		textField.setBounds(92, 28, 66, 21);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(92, 66, 66, 21);
		contentPanel.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(92, 106, 66, 21);
		contentPanel.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(92, 148, 66, 21);
		contentPanel.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(92, 189, 66, 21);
		contentPanel.add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnNewButton_12 = new JButton("BUY THIS");
		btnNewButton_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				ModifyTable modify=new ModifyTable();
				modify.setUri(uri);
				modify.setId(id);
				modify.setDatasourceName(datasorce);
				modify.setPassword(password);
			
				modify.setSQL("INSERT INTO buylist VALUES('"+act.account+"','"+act.password+"','"+act.id+"')");
				String backmess =modify.modifyRecord();
				textField_5.setText(backmess);
			
			}
		});
		btnNewButton_12.setBounds(255, 27, 113, 43);
		contentPanel.add(btnNewButton_12);
		
		JButton btnNewButton_13 = new JButton("VIEW YOURS");
		btnNewButton_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				QueryByAccount querybyaccount = new QueryByAccount();
				querybyaccount.setTableName("buylist");
				querybyaccount.setUri(uri);
				querybyaccount.setId(id);
				querybyaccount.setDatasourceName(datasorce);
				querybyaccount.setPassword(password);
				querybyaccount.setAccount(act.account);
				querybyaccount.getQuery();
				querybynumber.setNumber(querybyaccount.id);
				querybynumber.getQuery();
				textField_6.setText(querybynumber.str6+" "+querybynumber.str1+" "+querybynumber.str2+" "+querybynumber.str3+" "+querybynumber.str4+" "+querybynumber.str5);
				
			}
		});
		btnNewButton_13.setBounds(255, 105, 113, 43);
		contentPanel.add(btnNewButton_13);
		
		textField_5 = new JTextField();
		textField_5.setBounds(281, 189, 66, 21);
		contentPanel.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(180, 163, 242, 21);
		contentPanel.add(textField_6);
		textField_6.setColumns(10);
		

		
	}
}
