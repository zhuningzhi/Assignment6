package Assignment6;


import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class QueryByNumber extends Query {
int number;
int id;
String str1;
String str2;
String str3;
String str4;
String str5;
String str6;

public void setNumber (int number){
	this.number=number;
}
public void getQuery(){
	setSQL("select * from "+tableName+" where id = "+number);
	
	Connection con;
	Statement sql;
	ResultSet rs;
	try{
		String url=uri+"://"+id+"/"+datasourceName+"?"+ "user=root&password="+password;
		con =DriverManager.getConnection(url);
		DatabaseMetaData metadata =con.getMetaData();
		ResultSet rs1=metadata.getColumns(null, null, tableName, null);
		int num=0;
		while(rs1.next()){
			num++;
		}
		sql=con.createStatement();
		rs=sql.executeQuery(SQL);
		while(rs.next()){
			
			for(int k=1;k<=num;k++){
				if(k==1){str6=rs.getString(k);id=Integer.parseInt(str6);}
				if(k==2){str1=rs.getString(k);}
				if(k==3){str2=rs.getString(k);}
				if(k==4){str3=rs.getString(k);}
				if(k==5){str4=rs.getString(k);}
				if(k==6){str5=rs.getString(k);}
			}
		
		}
		con.close();
	}
	catch(SQLException e){
		e.printStackTrace();
	}
	
}
}

