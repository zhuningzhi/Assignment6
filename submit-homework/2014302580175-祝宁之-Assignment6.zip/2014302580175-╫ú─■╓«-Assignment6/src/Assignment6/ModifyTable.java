package Assignment6;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ModifyTable {
	String uri="";
	String id="";
	String datasourceName ="";
	String password ="";
	String SQL;
	String message="";
	public ModifyTable(){
		try {
			Class.forName("com.mysql.jdbc.Driver");} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();}
	}
	public void setUri(String s){uri=s;}
	public void setId(String s){id=s;}
	public void setDatasourceName(String s){datasourceName=s;}
	public void setPassword(String s){password=s;}
	public void setSQL(String SQL){this.SQL=SQL;}
	public String modifyRecord(){
		Connection con = null;
		Statement sql=null;
		try{
	
			String url=uri+"://"+id+"/"+datasourceName+"?"+ "user=root&password="+password;
		    con =DriverManager.getConnection(url);

		    sql=con.createStatement();
		    sql.execute(SQL);
		    message="have done";
		    con.close();
		    
			
		}
		catch(SQLException e){
			message="have bugs";
		}
		return message;
	}
}
